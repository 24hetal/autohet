package org.example;

public class BrowserSelector {

    String browserName= "Chrome";
    boolean cloud=true;
    public void openBrowser(){
    if (cloud){
    }
}
}
